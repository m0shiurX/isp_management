-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 23, 2017 at 12:05 PM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.1.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kp_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `billings`
--

CREATE TABLE `billings` (
  `id` int(10) NOT NULL,
  `customer_id` int(10) NOT NULL,
  `bill_amount` int(11) NOT NULL,
  `month` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `billings`
--

INSERT INTO `billings` (`id`, `customer_id`, `bill_amount`, `month`, `created_at`) VALUES
(1, 2, 500, 'October', '2017-10-23 05:36:09'),
(2, 3, 1000, 'October', '2017-10-23 05:36:09');

-- --------------------------------------------------------

--
-- Table structure for table `cash_collection`
--

CREATE TABLE `cash_collection` (
  `id` int(10) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `amount` bigint(20) NOT NULL,
  `payee` varchar(255) NOT NULL,
  `remarks` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cash_collection`
--

INSERT INTO `cash_collection` (`id`, `created_at`, `amount`, `payee`, `remarks`) VALUES
(1, '2017-10-23 09:03:09', 500, 'Moshiur', 'Nothing'),
(2, '2017-10-23 09:20:14', 500, 'mh', 'hhh');

-- --------------------------------------------------------

--
-- Table structure for table `cash_expanse`
--

CREATE TABLE `cash_expanse` (
  `id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `amount` bigint(20) NOT NULL,
  `purpose` text NOT NULL,
  `remarks` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cash_expanse`
--

INSERT INTO `cash_expanse` (`id`, `created_at`, `amount`, `purpose`, `remarks`) VALUES
(1, '2017-10-23 09:13:13', 200, 'h', 'No Remarks'),
(2, '2017-10-23 09:18:05', 500, 'among', 'amonge');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `full_name` varchar(50) NOT NULL,
  `nid` varchar(16) NOT NULL,
  `address` text,
  `conn_location` text NOT NULL,
  `email` varchar(30) NOT NULL,
  `ip_address` varchar(16) NOT NULL,
  `conn_type` varchar(10) NOT NULL,
  `package_id` int(10) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `dropped` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `full_name`, `nid`, `address`, `conn_location`, `email`, `ip_address`, `conn_type`, `package_id`, `contact`, `dropped`) VALUES
(2, 'Moshiur Rahman', '1995102252400006', 'Johurul Nagar', 'Johurul Nagar', 'unimrgm@gmail.com', '192.168.105.70', 'Prepaid', 1, '01766179196', 0),
(3, 'Mushfiqur Rahman', '1995101408800009', 'Bamunia, Pirgachchca, Gabtoli, Bogra', 'Johurul Nagar', 'unimrgm@gmail.com', '192.168.105.75', 'Prepaid', 2, '01719454658', 0);

-- --------------------------------------------------------

--
-- Table structure for table `kp_category`
--

CREATE TABLE `kp_category` (
  `cat_id` int(3) NOT NULL,
  `cat_name` varchar(20) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Category name for products table, parents to products';

--
-- Dumping data for table `kp_category`
--

INSERT INTO `kp_category` (`cat_id`, `cat_name`) VALUES
(2, 'MC'),
(1, 'ONU');

-- --------------------------------------------------------

--
-- Table structure for table `kp_products`
--

CREATE TABLE `kp_products` (
  `pro_id` int(3) NOT NULL COMMENT 'Product identity no',
  `pro_name` varchar(40) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Product name',
  `pro_unit` varchar(10) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Product unit',
  `pro_category` varchar(20) CHARACTER SET utf16 COLLATE utf16_unicode_ci NOT NULL COMMENT 'Product category: Child of kp_category table',
  `pro_details` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'Product details',
  `pro_dropped` int(1) NOT NULL DEFAULT '0' COMMENT 'If a product is dropped or not'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Table for individuals products';

--
-- Dumping data for table `kp_products`
--

INSERT INTO `kp_products` (`pro_id`, `pro_name`, `pro_unit`, `pro_category`, `pro_details`, `pro_dropped`) VALUES
(2, 'product Na me od ', 'kgw', 'MC', 'Product Details', 0),
(3, 'BDCOM- 1250', 'N/A', 'ONU', 'Product Details', 0),
(5, 'Moshiur Rahman', 'kg', 'ONU', 'Product Details', 0),
(6, 'M5', 'N/A', 'MC', 'NatoStation M5 by ubiquity', 0),
(7, 'Alpha 11', 'pcs', 'ONU', 'Alpha Radiator', 0),
(8, 'Product 2', 'N/A', 'ONU', 'Another Product', 0),
(9, 'Product 3', 'N/A', 'MC', 'Another Product', 0),
(11, 'BDCOM- 1200', 'N', 'ONU', 'Product Details', 0),
(12, 'Excell-220', 'kg', 'ONU', 'Excell Inage', 0);

-- --------------------------------------------------------

--
-- Table structure for table `kp_user`
--

CREATE TABLE `kp_user` (
  `user_id` int(11) NOT NULL,
  `user_name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `user_pwd` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `full_name` text COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` text COLLATE utf8_unicode_ci,
  `c_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `authentication` int(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `kp_user`
--

INSERT INTO `kp_user` (`user_id`, `user_name`, `user_pwd`, `full_name`, `email`, `contact`, `address`, `c_date`, `authentication`) VALUES
(32, 'moshiur', '$2y$10$Xk8TYun1Crr0gIS960sSCeh7rfXfQfK2VJ3rJ7SThN/6cehlop35O', 'Moshiur Rahman', 'unimrgm@gmail.com', '01719454658', 'Bogra', '2017-10-21 20:39:51', 0),
(33, 'misu', '$2y$10$xuIQ8LSURAJbGj8dD8Wr9.0PzbPq2qUvaLjmSwMh/5xEY.SHeKYnS', 'Mushfiqur Rahman', 'misu@gmail.com', '01719454658', 'Bogra', '2017-10-22 07:29:55', 0),
(34, 'admin', '$2y$10$51/xhfZqmMt6pr9HhXfZB.Punql5srC5vXtOEradf0Cs5Dg/FzHYy', 'Mr Admin', 'admin@netwaybd.com', '051-56565', 'Netway', '2017-10-23 15:28:31', 0);

-- --------------------------------------------------------

--
-- Table structure for table `packages`
--

CREATE TABLE `packages` (
  `id` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `fee` bigint(20) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `packages`
--

INSERT INTO `packages` (`id`, `name`, `fee`, `created_at`) VALUES
(1, '1 mbps', 500, '2017-10-23 05:34:00'),
(2, '2 mbps', 800, '2017-10-23 05:34:00');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(10) NOT NULL,
  `client_id` int(10) NOT NULL,
  `billing_id` int(10) NOT NULL,
  `paid_amount` int(11) NOT NULL,
  `g_date` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `client_id`, `billing_id`, `paid_amount`, `g_date`, `created_at`) VALUES
(1, 2, 1, 500, '2017-10-24', '2017-10-23 06:13:28');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `cdate` datetime DEFAULT CURRENT_TIMESTAMP,
  `provider` varchar(50) NOT NULL,
  `remarks` text NOT NULL,
  `recipient` varchar(50) NOT NULL,
  `type` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `product_id`, `quantity`, `cdate`, `provider`, `remarks`, `recipient`, `type`) VALUES
(1, 2, 5, '2017-10-22 15:29:39', 'BI', 'Bogra', '', 1),
(2, 2, 1, '2017-10-22 15:29:39', '', 'Remark', 'Cross', 0),
(13, 5, 8, '2017-10-22 00:00:00', 'Sunmoon', 'kbl', '', 1),
(15, 3, 50, '2017-10-22 00:00:00', 'Sunmoon', '', '', 1),
(16, 5, 4, '2017-10-22 00:00:00', '', '', 'bi', 0),
(17, 3, 7, '2017-10-22 00:00:00', '', '', 'bi', 0),
(18, 6, 2, '2017-10-22 00:00:00', 'Bogra Info', '', '', 1),
(19, 7, 4, '2017-10-22 00:00:00', '', '', 'bi', 0),
(20, 8, 60, '2017-10-23 00:00:00', 'Netway', '', '', 1),
(21, 9, 12, '2017-10-23 00:00:00', 'Dhaka', '', '', 1),
(23, 12, 6, '2017-10-23 00:00:00', 'Dhaka', '', '', 1),
(24, 11, 10, '2017-10-23 00:00:00', 'Bogra Info', '', '', 1),
(25, 7, 50, '2017-10-23 00:00:00', 'Bogra Info', 'none', '', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `billings`
--
ALTER TABLE `billings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cash_collection`
--
ALTER TABLE `cash_collection`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cash_expanse`
--
ALTER TABLE `cash_expanse`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nid` (`nid`);

--
-- Indexes for table `kp_category`
--
ALTER TABLE `kp_category`
  ADD PRIMARY KEY (`cat_id`),
  ADD KEY `cat_name` (`cat_name`);

--
-- Indexes for table `kp_products`
--
ALTER TABLE `kp_products`
  ADD PRIMARY KEY (`pro_id`),
  ADD UNIQUE KEY `pro_name` (`pro_name`),
  ADD KEY `pro_category` (`pro_category`);

--
-- Indexes for table `kp_user`
--
ALTER TABLE `kp_user`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `user_name` (`user_name`);

--
-- Indexes for table `packages`
--
ALTER TABLE `packages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `billings`
--
ALTER TABLE `billings`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `cash_collection`
--
ALTER TABLE `cash_collection`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `cash_expanse`
--
ALTER TABLE `cash_expanse`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `kp_category`
--
ALTER TABLE `kp_category`
  MODIFY `cat_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `kp_products`
--
ALTER TABLE `kp_products`
  MODIFY `pro_id` int(3) NOT NULL AUTO_INCREMENT COMMENT 'Product identity no', AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `kp_user`
--
ALTER TABLE `kp_user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;
--
-- AUTO_INCREMENT for table `packages`
--
ALTER TABLE `packages`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
